<?php
/**
 * The template for displaying the footer.
 *
 * @package woostify
 */

do_action( 'woostify_theme_footer' );
wp_footer();
?>

</body>
</html>
