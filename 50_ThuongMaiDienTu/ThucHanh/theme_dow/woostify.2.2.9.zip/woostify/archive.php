<?php
/**
 * The template for displaying archive pages.
 *
 * Learn more: https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package woostify
 */

get_header();

do_action( 'woostify_theme_archive' );

get_footer();
