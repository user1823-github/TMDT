<a href="<?php the_permalink();?>">
    <?php the_post_thumbnail('large'); ?>
</a>