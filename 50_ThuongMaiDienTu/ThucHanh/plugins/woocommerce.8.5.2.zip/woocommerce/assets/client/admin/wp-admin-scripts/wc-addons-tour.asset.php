<?php return array('dependencies' => array('wc-components', 'wc-store-data', 'wc-tracks', 'wp-data', 'wp-element', 'wp-i18n'), 'version' => '50f98600d19a0b50f85f');
