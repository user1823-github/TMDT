<?php return array('dependencies' => array('wc-customer-effort-score', 'wc-navigation'), 'version' => 'aee1eed61c36fa9829fb');
