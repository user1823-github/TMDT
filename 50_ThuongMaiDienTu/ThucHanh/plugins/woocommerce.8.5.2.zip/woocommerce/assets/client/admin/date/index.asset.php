<?php return array('dependencies' => array('lodash', 'moment', 'wp-i18n'), 'version' => '0cea4d70d538db5e6e51');
