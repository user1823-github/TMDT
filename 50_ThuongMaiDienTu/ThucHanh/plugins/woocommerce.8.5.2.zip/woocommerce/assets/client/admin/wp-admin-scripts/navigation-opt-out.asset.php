<?php return array('dependencies' => array('wp-components', 'wp-element', 'wp-i18n'), 'version' => '5d4fe7ffa73377466806');
