<?php return array('dependencies' => array('wc-customer-effort-score'), 'version' => 'fd9b31494932f140e58c');
