<?php return array('dependencies' => array('wc-components', 'wp-components', 'wp-element'), 'version' => '0d0f94b6015dbbb69f66');
