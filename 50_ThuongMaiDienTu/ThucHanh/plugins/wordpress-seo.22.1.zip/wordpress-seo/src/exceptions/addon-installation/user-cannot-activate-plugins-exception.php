<?php

namespace Yoast\WP\SEO\Exceptions\Addon_Installation;

use Exception;

/**
 * Class User_Cannot_Activate_Plugins
 */
class User_Cannot_Activate_Plugins_Exception extends Exception {}
