<?php
/**
 * Template for the modal form
 *
 * This template can be overridden by copying it to yourtheme/ultimate-member/modal/um_upload_single.php
 *
 * @version 2.6.1
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
} ?>

<div id="um_upload_single" style="display:none"></div>
