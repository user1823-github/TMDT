<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>


<div id="UM_fields" style="display:none">

	<div class="um-admin-modal-head">
		<h3><?php _e( 'Fields Manager', 'ultimate-member' ); ?></h3>
	</div>

	<div class="um-admin-modal-body"></div>

</div>